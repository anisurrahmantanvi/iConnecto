var i=Object.defineProperty;var s=(a,r)=>i(a,"name",{value:r,configurable:!0});import{l as n,j as e,I as h}from"./index-CluYYBEZ.js";import{X as u}from"./x-MtYZS5MY.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=n("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);function j({value:a,onChange:r,label:c,placeholder:t,autoFocus:l}){return e.jsxs("div",{className:"glass search-box",role:"search",children:[e.jsx(x,{size:18,"aria-hidden":!0}),e.jsx("input",{type:"search",className:"search-box__input","aria-label":c,placeholder:t??c,value:a,autoFocus:l,autoComplete:"off",autoCapitalize:"none",spellCheck:!1,maxLength:50,onChange:s(o=>r(o.target.value),"onChange")}),a?e.jsx(h,{label:"Clear search",small:!0,onClick:s(()=>r(""),"onClick"),children:e.jsx(u,{size:16})}):null]})}s(j,"SearchBox");export{j as S};
